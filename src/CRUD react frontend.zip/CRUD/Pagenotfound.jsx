import React from 'react';


const Err = () => {

    return (
    <div>
        <center>
            <h1>Page not found Error 404</h1>
        </center>

    </div>);
}


export default Err;